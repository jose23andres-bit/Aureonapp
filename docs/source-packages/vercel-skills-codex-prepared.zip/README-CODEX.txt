# Vercel Skills bundle for Codex

This bundle contains the 3 SKILL.md files actually present in the ZIP uploaded in this conversation, copied into Codex's project skill layout (`.agents/skills/`).

Included skills:
- find-skills
- pr-labeling
- triage

Important: the uploaded repository is the `vercel-labs/skills` CLI/tool repository, not the separate `vercel-labs/agent-skills` catalog. Therefore this bundle does NOT claim to contain every skill published by Vercel. The official catalog can be installed in a Codex environment using the Vercel Skills CLI.

Official sources:
- https://github.com/vercel-labs/skills
- https://github.com/vercel-labs/agent-skills
